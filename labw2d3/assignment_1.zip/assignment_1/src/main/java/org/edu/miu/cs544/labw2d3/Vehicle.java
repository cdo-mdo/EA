package org.edu.miu.cs544.labw2d3;

public interface Vehicle {
    void move();
}
