package org.edu.miu.cs544.labw2d3;

public class Car implements Vehicle {
    @Override
    public void move() {
        System.out.println("moving at 50mph");
    }
}
