package org.edu.miu.cs544.labw2d3;

public class Game {
    private Vehicle vehicle;
    public Game(Vehicle vehicle) {
        this.vehicle = vehicle;
    }
    public void play() {
        vehicle.move();
    }
}
