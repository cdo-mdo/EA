package org.edu.miu.cs544.assignment_2.data;

public class Car extends Vehicle {
    private int seatingCapacity;
    private String fuelType;
}
