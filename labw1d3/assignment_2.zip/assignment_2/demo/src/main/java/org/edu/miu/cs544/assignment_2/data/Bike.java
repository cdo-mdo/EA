package org.edu.miu.cs544.assignment_2.data;

public class Bike extends Vehicle {
    private int engineCapacity;
}
