package org.edu.miu.cs544.assignment_2.data;

public enum PaymentMethod {
    CASH,
    CREDIT_CARD,
    ONLINE
}
