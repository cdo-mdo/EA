package org.edu.miu.cs.cs544.final_exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalExamApplicationTests {

    @Test
    void contextLoads() {
    }

}
