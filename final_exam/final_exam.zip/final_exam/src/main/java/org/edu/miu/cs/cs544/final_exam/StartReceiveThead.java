package org.edu.miu.cs.cs544.final_exam;

import org.edu.miu.cs.cs544.final_exam.service.MessageReceiveThread;
import org.edu.miu.cs.cs544.final_exam.service.MessageReceiveThread2;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class StartReceiveThead implements CommandLineRunner {



    @Override
    public void run(String... args) throws Exception {
        MessageReceiveThread thread1 = new MessageReceiveThread();
        MessageReceiveThread2 thread2 = new MessageReceiveThread2();
        thread1.run();
        thread2.run();
    }
}
